﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.Json;
using System.Windows.Forms;

namespace WritingToolGUI
{
    public partial class editForm : Form
    {
        public editForm()
        {
            InitializeComponent();

        }

        public editForm(string type)
        {
            InitializeComponent();
            Text = "Add " + type;
            itemType = type;

        }

        public editForm(Item item, int itemIndex)
        {
            InitializeComponent();
            txtEditName.Text = item.Name;
            txtEditDescription.Text = item.Description;
            txtEditTags.Text = string.Join(", ", item.Tags);
            currentItem = item;

        }

        public static string editName;
        public static string editDescription;

        public static List<string> editTags = new List<string>();

        public static string itemType;
        public static Item currentItem;
        private void btnEditSubmit_Click(object sender, EventArgs e)
        {
            SubmitInfo();

            Close();
        }

        private void editForm_Load(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private bool ValidateName()
        {
            bool isValid = false;
            if (string.IsNullOrWhiteSpace(txtEditName.Text))
            {
                MessageBox.Show("Name cannot be empty", "Info", MessageBoxButtons.OK);
            }
            else
            {
                isValid = true;
            }
            return isValid;
        }

        private void SubmitInfo()
        {
            bool valid;
            valid = ValidateName();

            if (valid == true)
            {
                editName = txtEditName.Text;
                editDescription = txtEditDescription.Text;
                editTags = new List<string>(txtEditTags.Text.Split(','));

                Close();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            currentItem.Status = "Deleted";
           Close();
        }
    }
}
