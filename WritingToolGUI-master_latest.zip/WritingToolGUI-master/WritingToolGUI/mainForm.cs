
using Microsoft.VisualBasic.ApplicationServices;
using System.Text.Json;
using System.Linq;

namespace WritingToolGUI
{
    public partial class mainForm : Form
    {
        public mainForm()
        {
            InitializeComponent();

        }


        public static int currentPageIndex = 1;

        public static List<Item> displayList = new List<Item>();
        private void btnQuit_Click(object sender, EventArgs e)
        {
            //Exits the application
            Application.Exit();
        }

        private void btnAddCharacter_Click(object sender, EventArgs e)
        {
            

            AddCharacter();
           

            UpdateDisplayList();
            

        }

        private void AddCharacter()
        {
            //Opens a new form for the user to write in
            lblWelcome.Visible = false;
            string type = "Character";
            editForm editForm = new editForm(type);

            editForm.ShowDialog();

            if (editForm.editName != null)
            {

                Character.AddCharacter(editForm.editName, editForm.editDescription, editForm.editTags);
                Item.itemsTotal.Add(new Character
                {
                    Name = editForm.editName,
                    Description = editForm.editDescription,
                    Tags = editForm.editTags,
                    Date = DateTime.Now.ToString("MM/dd/yy"),
                    Type = "Character"
                });
            }

        }

        private void btnAddProject_Click(object sender, EventArgs e)
        {
           

            AddProject();

            UpdateDisplayList();

        }

        private void AddProject()

        {
            //Opens a new form for the user to write in
            lblWelcome.Visible = false;
            editForm editForm = new editForm();
            editForm.ShowDialog();
            if (editForm.editName != null)
            {
                Project.AddProject(editForm.editName, editForm.editDescription, editForm.editTags);
                Item.itemsTotal.Add(new Project
                {
                    Name = editForm.editName,
                    Description = editForm.editDescription,
                    Tags = editForm.editTags,
                    Date = DateTime.Now.ToString("MM/dd/yy"),
                    Type = "Project"
                });
            }

        }

        // Pagination does not work
        private void btnNext_Click(object sender, EventArgs e)
        {
            NextPage();
            CheckNextButtonVisible();
        }

        private void NextPage()
        {
            currentPageIndex += 1;
            UpdateDisplayList();
            btnBack.Visible = true;
        }

        public void SaveAll()
        {

            string fileName = "All.json";
            string filePath = Path.Combine(Environment.CurrentDirectory, fileName);
            var options = new JsonSerializerOptions { WriteIndented = true };
            string jsonString = JsonSerializer.Serialize(Item.itemsTotal, options);
            File.WriteAllText(filePath, jsonString);
        }

        public void SaveCharacters()
        {
            string fileName = "Characters.json";
            string filePath = Path.Combine(Environment.CurrentDirectory, fileName);
            var options = new JsonSerializerOptions { WriteIndented = true };
            string jsonString = JsonSerializer.Serialize(Character.characterList, options);
            File.WriteAllText(filePath, jsonString);
        }

        public void SaveProjects()
        {
            string fileName = "Projects.json";
            string filePath = Path.Combine(Environment.CurrentDirectory, fileName);
            var options = new JsonSerializerOptions { WriteIndented = true };
            string jsonString = JsonSerializer.Serialize(Project.projectList, options);
            File.WriteAllText(filePath, jsonString);
        }

        public void LoadCharacters()
        {
            {
                string fileName = "Characters.json";
                string filePath = Path.Combine(Environment.CurrentDirectory, fileName);
                if (File.Exists(filePath))
                    try
                    {
                        MessageBox.Show("File exists.");
                        string jsonString = File.ReadAllText(filePath);
                        Character.characterList = JsonSerializer.Deserialize<List<Character>>(jsonString);
                        UpdateDisplayList();
                        CheckNextButtonVisible();
                    }
                    catch (FileNotFoundException)
                    {
                        MessageBox.Show("File not found.", "Error", MessageBoxButtons.OK);
                    }
                    catch (JsonException)
                    {
                        MessageBox.Show("JSON is invalid.", "Error", MessageBoxButtons.OK);
                    }
                    catch (IOException)
                    {
                        MessageBox.Show("Error processing file.", "Error", MessageBoxButtons.OK);
                    }
                    catch (UnauthorizedAccessException)
                    {
                        MessageBox.Show("Access denied.", "Error", MessageBoxButtons.OK);

                    }
                    catch (Exception)
                    {
                        MessageBox.Show("An error has occurred.", "Error", MessageBoxButtons.OK);
                    }
                else
                {
                    MessageBox.Show("No previous entries found.", "Error", MessageBoxButtons.OK);
                }
            }

        }
        public void LoadProjects()
        {
            {
                string fileName = "Projects.json";
                string filePath = Path.Combine(Environment.CurrentDirectory, fileName);
                if (File.Exists(filePath))
                    try
                    {
                        MessageBox.Show("File exists.");
                        string jsonString = File.ReadAllText(filePath);
                        Project.projectList = JsonSerializer.Deserialize<List<Project>>(jsonString);
                        UpdateDisplayList();
                        CheckNextButtonVisible();
                    }
                    catch (FileNotFoundException)
                    {
                        MessageBox.Show("File not found.", "Error", MessageBoxButtons.OK);
                    }
                    catch (JsonException)
                    {
                        MessageBox.Show("JSON is invalid.", "Error", MessageBoxButtons.OK);
                    }
                    catch (IOException)
                    {
                        MessageBox.Show("Error processing file.", "Error", MessageBoxButtons.OK);
                    }
                    catch (UnauthorizedAccessException)
                    {
                        MessageBox.Show("Access denied.", "Error", MessageBoxButtons.OK);

                    }
                    catch (Exception)
                    {
                        MessageBox.Show("An error has occurred.", "Error", MessageBoxButtons.OK);
                    }
                else
                {
                    MessageBox.Show("No previous entries found.", "Error", MessageBoxButtons.OK);
                }
            }
        }
        public void LoadAll()
        {
            string fileName = "All.json";
            string filePath = Path.Combine(Environment.CurrentDirectory, fileName);
            if (File.Exists(filePath))
                try
                {
                    MessageBox.Show("File exists.");
                    string jsonString = File.ReadAllText(filePath);
                    Item.itemsTotal = JsonSerializer.Deserialize<List<Item>>(jsonString);
                    UpdateDisplayList();
                    CheckNextButtonVisible();
                }
                catch (FileNotFoundException)
                {
                    MessageBox.Show("File not found.", "Error", MessageBoxButtons.OK);
                }
                catch (JsonException)
                {
                    MessageBox.Show("JSON is invalid.", "Error", MessageBoxButtons.OK);
                }
                catch (IOException)
                {
                    MessageBox.Show("Error processing file.", "Error", MessageBoxButtons.OK);
                }
                catch (UnauthorizedAccessException)
                {
                    MessageBox.Show("Access denied.", "Error", MessageBoxButtons.OK);

                }
                catch (Exception)
                {
                    MessageBox.Show("An error has occurred.", "Error", MessageBoxButtons.OK);
                }
            else
            {
                MessageBox.Show("No previous entries found.", "Error", MessageBoxButtons.OK);
            }
        }



        //Can't get pagination to work. Considering removing this and having a scrollbar 
        public void UpdateText()
        {
            int displayCount = displayList.Count();

            switch (displayCount)
            {
                case 0:
                    MakeLinkInvisible(1);
                    MakeLinkInvisible(2);
                    MakeLinkInvisible(3);
                    MakeLinkInvisible(4);
                    MakeLinkInvisible(5);
                    break;
                case 1:
                    DisplayFirstLink();
                    MakeLinkVisible(1);
                    MakeLinkInvisible(2);
                    MakeLinkInvisible(3);
                    MakeLinkInvisible(4);
                    MakeLinkInvisible(5);
                    break;
                case 2:
                    DisplayFirstLink();
                    DisplaySecondLink();
                    MakeLinkVisible(1);
                    MakeLinkVisible(2);
                    MakeLinkInvisible(3);
                    MakeLinkInvisible(4);
                    MakeLinkInvisible(5);
                    break;
                case 3:
                    DisplayFirstLink();
                    DisplaySecondLink();
                    DisplayThirdLink();
                    MakeLinkVisible(1);
                    MakeLinkVisible(2);
                    MakeLinkVisible(3);
                    MakeLinkInvisible(4);
                    MakeLinkInvisible(5);


                    break;
                case 4:
                    DisplayFirstLink();
                    DisplaySecondLink();
                    DisplayThirdLink();
                    DisplayFourthLink();
                    MakeLinkVisible(1);
                    MakeLinkVisible(2);
                    MakeLinkVisible(3);
                    MakeLinkVisible(4);
                    MakeLinkInvisible(5);
                    break;
                default:
                    DisplayFirstLink();
                    DisplaySecondLink();
                    DisplayThirdLink();
                    DisplayFourthLink();
                    DisplayFifthLink();
                    MakeLinkVisible(1);
                    MakeLinkVisible(2);
                    MakeLinkVisible(3);
                    MakeLinkVisible(4);
                    MakeLinkVisible(5);
                    break;
            }

        }
        public void DisplayFirstLink()
        {
            lnkItem1.Text = displayList[0].Name;
            lblDate1.Text = displayList[0].Date;
            lblTags1.Text = string.Join(", ", displayList[0].Tags);
        }

        public void DisplaySecondLink()
        {
            lnkItem2.Text = displayList[1].Name;
            lblDate2.Text = displayList[1].Date;
            lblTags2.Text = string.Join(", ", displayList[1].Tags);
        }

        public void DisplayThirdLink()
        {
            lnkItem3.Text = displayList[2].Name;
            lblDate3.Text = displayList[2].Date;
            lblTags3.Text = string.Join(", ", displayList[2].Tags);
        }

        public void DisplayFourthLink()
        {
            lnkItem4.Text = displayList[3].Name;
            lblDate4.Text = displayList[3].Date;
            lblTags4.Text = string.Join(", ", displayList[3].Tags);
        }

        public void DisplayFifthLink()
        {
            lnkItem5.Text = displayList[4].Name;
            lblDate5.Text = displayList[4].Date;
            lblTags5.Text = string.Join(", ", displayList[4].Tags);
        }

        public void UpdateDisplayList()
        {
            displayList.Clear();
            int itemRange = ((currentPageIndex - 1) * 5);
            int endRange = Item.itemsTotal.Count() - 1;
            if (Item.itemsTotal.Count == 1)
            {
                endRange = 0;
                displayList.Add(Item.itemsTotal[0]);
            }
            else
            {
                for (int i = itemRange; i <= endRange; ++i)
                {
                    displayList.Add(Item.itemsTotal[i]);
                }

            }
            UpdateText();
            CheckNextButtonVisible();

        }

        public void ClearLinkText(int linkIndex)
        {
            switch (linkIndex)
            {
                case 1:
                    lnkItem1.Text = "";
                    lblDate1.Text = "";
                    lblTags1.Text = "";
                    break;
                case 2:
                    lnkItem2.Text = "";
                    lblDate2.Text = "";
                    lblTags2.Text = "";
                    break;
                case 3:
                    lnkItem3.Text = "";
                    lblDate3.Text = "";
                    lblTags3.Text = "";
                    break;
                case 4:
                    lnkItem4.Text = "";
                    lblDate4.Text = "";
                    lblTags4.Text = "";
                    break;
                case 5:
                    lnkItem5.Text = "";
                    lblDate5.Text = "";
                    lblTags5.Text = "";
                    break;
            }
        }

        public void MakeLinkInvisible(int linkIndex)
        {
            switch (linkIndex)
            {
                case 1:
                    lnkItem1.Visible = false;
                    lblDate1.Visible = false;
                    lnkEdit1.Visible = false;
                    lblTags1.Visible = false;
                    break;
                case 2:
                    lnkItem2.Visible = false;
                    lblDate2.Visible = false;
                    lnkEdit2.Visible = false;
                    lblTags2.Visible = false;
                    break;
                case 3:
                    lnkItem3.Visible = false;
                    lblDate3.Visible = false;
                    lnkEdit3.Visible = false;
                    lblTags3.Visible = false;
                    break;
                case 4:
                    lnkItem4.Visible = false;
                    lblDate4.Visible = false;
                    lnkEdit4.Visible = false;
                    lblTags4.Visible = false;
                    break;
                case 5:
                    lnkItem5.Visible = false;
                    lblDate5.Visible = false;
                    lnkEdit5.Visible = false;
                    lblTags5.Visible = false;
                    break;
            }
        }
        public void MakeLinkVisible(int linkIndex)
        {
            if (linkIndex <= 5)
            {
                switch (linkIndex)
                {
                    case 1:
                        lnkItem1.Visible = true;
                        lblDate1.Visible = true;
                        lnkEdit1.Visible = true;
                        lblTags1.Visible = true;
                        break;
                    case 2:
                        lnkItem2.Visible = true;
                        lblDate2.Visible = true;
                        lnkEdit2.Visible = true;
                        lblTags2.Visible = true;
                        break;
                    case 3:
                        lnkItem3.Visible = true;
                        lblDate3.Visible = true;
                        lnkEdit3.Visible = true;
                        lblTags3.Visible = true;
                        break;
                    case 4:
                        lnkItem4.Visible = true;
                        lblDate4.Visible = true;
                        lnkEdit4.Visible = true;
                        lblTags4.Visible = true;
                        break;
                    case 5:
                        lnkItem5.Visible = true;
                        lblDate5.Visible = true;
                        lnkEdit5.Visible = true;
                        lblTags5.Visible = true;
                        break;
                }
            }

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            PreviousPage();
            CheckNextButtonVisible();
        }

        private void PreviousPage()
        {
            currentPageIndex -= 1;
            UpdateDisplayList();

            if (currentPageIndex == 1)
            {
                btnBack.Visible = false;
            }
        }

        private void makeEditForm(int editIndex)
        {
            editForm editForm = new editForm(Item.itemsTotal[editIndex], editIndex);

            if (Item.itemsTotal[editIndex].Type == "Character")
            {
                editForm.Text = $"Edit Character: {Item.itemsTotal[editIndex].Name}";
                editForm.ShowDialog();
                
            }
            else
            {
                editForm.Text = $"Edit Project: {Item.itemsTotal[editIndex].Name}";
                editForm.ShowDialog();
                
            }
            
            Item.Edit(Item.itemsTotal[editIndex], editForm.editName, editForm.editDescription, editForm.editTags);
            if (Item.itemsTotal[editIndex].Status == "Deleted")
            {
                if (Item.itemsTotal[editIndex].Type == "Character")
                {
                    var results = (Character.characterList.FirstOrDefault(character => character.Name == Item.itemsTotal[editIndex].Name));
                    Item.Delete(Item.itemsTotal[editIndex]);
                    Character.RemoveCharacter(results);
                    
                }
                else
                {
                    var results = (Project.projectList.FirstOrDefault(project => project.Name == Item.itemsTotal[editIndex].Name));
                    Item.Delete(Item.itemsTotal[editIndex]);
                    Project.RemoveProject(results);

                }
                currentPageIndex = 1;
                CheckNextButtonVisible();
            }
            else
            {
                if (Item.itemsTotal[editIndex].Type == "Character")
                {
                    Character.EditCharacter(Character.characterList[editIndex],
                        editForm.editName, editForm.editDescription, editForm.editTags);
                }
                else
                {
                    Project.EditProject(Project.projectList[editIndex],
                    editForm.editName, editForm.editDescription, editForm.editTags);
                }

            }

        }

        private void lnkEdit1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            int editIndex = ((currentPageIndex - 1) * 5);
            makeEditForm(editIndex);
            UpdateDisplayList();
        }

        private void lnkEdit2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            int editIndex = ((currentPageIndex - 1) * 5) + 1;
            makeEditForm(editIndex);
            UpdateDisplayList();
        }

        private void lnkEdit3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            int editIndex = ((currentPageIndex - 1) * 5) + 2;
            makeEditForm(editIndex);
            UpdateDisplayList();
        }

        private void lnkEdit4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            int editIndex = ((currentPageIndex - 1) * 5) + 3;
            makeEditForm(editIndex);
            UpdateDisplayList();

        }

        private void lnkEdit5_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            int editIndex = ((currentPageIndex - 1) * 5) + 4;
            makeEditForm(editIndex);
            UpdateDisplayList();

        }

        private void mainForm_Load(object sender, EventArgs e)
        {
            btnNext.Visible = false;
            btnBack.Visible = false;
            LoadAll();
            LoadProjects();
            LoadCharacters();
        }

        private void CheckNextButtonVisible()
        {
            if (displayList.Count < 5 || Item.itemsTotal.Count() % 5 == 0)
            {
                btnNext.Visible = false;

            }
            else
            {
                btnNext.Visible = true;
            }
        }
        private void btnLoadJson_Click(object sender, EventArgs e)
        {
            LoadAll();
            LoadProjects();
            LoadCharacters();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveAll();
            SaveProjects();
            SaveCharacters();
        }
    }
}
